---
name: solterra-batch-translation
description: >-
  Translate Subaru Solterra owner's-manual and automotive UI content from English into Dutch using a six-column CSV workfile. Trigger this skill whenever a CSV is supplied whose columns are, in order, English | Translation | Replacements | Terminology | Translation Memory | Notes — including rows carrying `TERMS: {...}` dictionaries or `[FUZZY nn%]` pre-fills. Also trigger when the user mentions "Solterra", "Subaru batch", "Solterra CSV", or EN→NL automotive manual translation with pre-matched terminology, even without naming the skill. Do NOT trigger for Honda diagnostic EN→NL work (HONDA_SENTINEL_V3), Dutch→English machinery content (agri-machinery-nl-en), or Afrikaans→English minutes (gsa-batch-translation).
---

Solterra Localisation: English → Dutch
=====================================

Client: Subaru Solterra (battery-electric vehicle). Content: owner's manual,
multimedia/navigation UI, safety notices, spec lines.

Operating Model
---------------

This skill is **never used alone**. It is always paired with a workfile CSV
(`output.csv` or equivalent) whose columns carry all segment-specific data.
The workfile is the primary source of truth; the bundled reference files
supply the client's standing glossary where a row's columns are empty.

**Never import Dutch terminology from the Honda work into this client.** The
two clients diverge on core vocabulary (Solterra: *batterij*,
*tractiebatterij*; Honda: *accu*). Solterra terminology comes from the
workfile columns first, then the master list (`reference/terminology.csv`),
and nowhere else. See The Master Terminology List below.

The CSV Contract
----------------

Six columns, in order. Read all six per row before translating. A context
file may accompany it — see The Context File below.

| Column | Content | Your obligation |
| --- | --- | --- |
| 1. English | Source string | Translate this, exactly as scoped |
| 2. Translation | Empty, or a `[FUZZY nn%]` pre-fill | **Your output goes here**; strip the tag |
| 3. Replacements | `TERMS: {...}` dict plus a `PATTERN: [...]` term list | Binding where the key matches the source |
| 4. Terminology | `"en" -> "nl"` pairs; same data as col 3 in display form | Binding |
| 5. Translation Memory | `en -> nl` pairs harvested from TM | Support only — adapt, never paste blindly |
| 6. Notes | Empty, or upstream fuzzy/mandatory remarks | Append your coded note (see Notes Taxonomy) |

An empty `TERMS: {}` means no terminology exists for the row: translate
fresh under this skill's style rules, check `reference/terminology.csv` for
a standing match, and mark the row `FRESH` in Notes.

`PATTERN: [Contactschakelaar] [Aan] [Indicatielampje]` is an unordered bag
of the same terms, **not a sentence skeleton**. Never build a sentence by
stringing the bracketed items together.

### Priority Hierarchy (strict)

1. **Context validity** — the translation must be correct for what the
   string *is* (UI label, caption, warning, spec line). A terminology match
   that produces nonsense in context is escalated with `HARMONISE:`, not
   applied silently.
2. **Replacements / Terminology columns and the master list** — exact
   matches are binding.
3. **Confirmed neighbouring segments** in the context file, where one is
   supplied (see below). A neighbour outranks the TM, but not the master
   list: where the list has an entry, a neighbour that differs is legacy
   drift.
4. **Translation Memory column**, then `reference/translation-memory.csv`.
5. **Patterns** — `reference/patterns.csv` and the structural patterns below.
6. **Fuzzy pre-fill / machine output** — lowest. A draft to be repaired,
   never evidence of correctness.

Where levels conflict, apply the higher level and record the conflict in
Notes with the `HARMONISE:` prefix.

The Master Terminology List
---------------------------

`reference/terminology.csv` is an unaltered copy of the user's master
list, kept on GitHub (`fdefoglio/Solterra`, `terminology.csv`): every
field quoted, CRLF line endings. The GitHub file is the master; the copy
exists only as a fallback. It holds client-
mandated terms and terms standardised locally by the user; only the user's
CAT tool shows which is which. Locally standardised terms are later
approved and mandated by the client, so treat **every entry as binding**.
It is the only terminology list for this client.

**Refresh before a batch.** If `bash_tool` has network access, fetch the
live list first, because the user adds to it between batches:

```bash
curl -sSL -o /tmp/terminology.csv https://raw.githubusercontent.com/fdefoglio/Solterra/main/terminology.csv
```

If the download succeeds and parses as two columns under an
`english,dutch` header, use it in place of the bundled copy. If it fails, use
the bundled copy and say so in one line of the reply, so the user knows newer
entries may be missing. Rows that do not parse into two columns are
skipped and listed for the user to fix on GitHub. Read the list; never
rewrite, re-quote or repair the bundled copy, so it stays identical to
GitHub.

**Matching.** Match case-insensitively on whole words, longest entry
first. A match survives inflection and an inserted article (*het
voorgaande voertuig*, *afstand tot de voorligger*); neither is a
deviation.

**Legacy TM.** Several translators have worked on this project over the
years, so confirmed segments can deviate from the list. The list decides:

* If the list has an entry and a confirmed segment in the window uses a
  different form, report it as house-term drift in the Outside-the-batch
  report, whatever the segment's status.
* If a confirmed segment matches the list, it is correct. Do not report
  the entry's wording as a defect, even where it reads unusually (*de
  zijradarsensoren vóór*); the user has already settled it.
* If an entry itself looks wrong (a meaning error, a truncated or
  malformed row), raise it as a question for the user rather than a
  defect, since it may be mandated.
* If the list has no entry and the TM or the window shows competing
  renderings, propose one standard with its evidence (TM majority, the
  pattern of related list entries, a quick web check for an OEM form) and
  say which segments would change. The user adds the agreed form to the
  list.

**Normalisation deliverable.** When the user asks to normalise segments to
the list or to an agreed standard, return a `"current","to_replace"` CSV
in a code block, one full segment string per row, so each replacement is
unambiguous in the CAT tool. Apply every rule of this skill to each
`to_replace` string, including Word Repetition: a replacement that
introduces a repeat is recast. Follow it with a short list of what changed
and why, phrased for the client note, and name any matching segments
deliberately left unchanged (for example, a term bound by a different
entry).

The Context File
----------------

The workfile is a filtered pull: only the segments needing work, order
incidental. A second file, `context_T1.csv` or equivalent, may be supplied
alongside it, rebuilding the translator's CAT view — every segment of the
language pair in **document order**, with the confirmed Dutch above and
below each batch segment. It is produced by `transit_context.py` from the
Transit `.ENU`/`.NLD` pair.

**Read it before translating any row, not as a lookup afterwards.** It is
read-only: nothing is ever written back to it, and the workfile remains the
sole delivery artefact.

| Column | Content |
| --- | --- |
| `Seg` | Transit segment number; document order |
| `Struct` | Innermost three document elements — `row/entry/p`, `note_body/note_para/title`, `att_list1_item/itemtxt` |
| `Status` | Segment status, decoded from Transit's own status field |
| `StatusCode` | Raw status code, for verifying the label |
| `Author` | Who last confirmed the segment |
| `EN` / `NL` | Source and target; `NL` is blank where the status is Not translated |
| `Batch` | Row number in the workfile, blank for context-only segments |

A `...` row with `(gap: n segments)` marks a break in the run. Rows either
side of it are **not** neighbours; never read them as consecutive.

Status values: *Translated* (confirmed, house style), *Not translated*
(the batch's own segments), *Not for translation* (markup and cross-
references copied through), *Edited, unconfirmed* (recently changed, not
yet confirmed — weaker evidence than *Translated*).

### What to take from it

* **House terms.** A confirmed neighbour outranks the TM column for
  terminology and register, because it is this document, this section.
  It does not outrank the master list: where the list has an entry, follow
  the list and report the neighbour as drift.
  Where a *full-segment* TM pair and a confirmed neighbour disagree on a
  whole string, apply the higher level but raise `HARMONISE:` rather than
  overriding silently.
* **Register and structure.** `Struct` says whether a string is a table
  cell, a list item, a heading or a footnote. Match the siblings: list
  items that are conditions stay plain present-tense statements; table
  cells stay nominal and article-free.
* **Referents.** What the previous segment left standing decides whether
  an anaphor is safe in this one — see the Word Repetition rules.
* **Revision traps.** A near-identical confirmed segment beside a batch
  segment is often the *previous revision* of the same sentence. Its Dutch
  is correct for the old English and is frequently what the fuzzy pre-fill
  was built from. Translate the delta and raise `HARMONISE:` if both
  versions now stand in the same list.
* **Stored form over earlier delivery.** Where the TM column or a fuzzy
  source shows a unit stored differently from what an earlier batch
  delivered, the reviewer has edited it since. Follow the stored form for
  sibling segments and say so under `CONSISTENCY:`.

Note the evidence in the row's Notes with the `CONTEXT:` prefix, giving the
segment numbers relied on.

### Limits

* Batch rows are matched to segments by exact English text. A row whose
  inline content was stripped during extraction — a cross-reference reduced
  to `()`, a button label to `“”` — will not match. Locate it from its
  neighbours instead, reproduce the empty placeholder exactly as column 1
  supplies it, and mark `INPUT-ERR:`.
* One workfile row may correspond to **two** Transit segments joined at a
  full stop. Say so in Notes so the delivery can be split on re-import.
* The window is counted in segment numbers, not structure, so it can cut a
  table in half. Absence of evidence in the window is not evidence of
  absence.

### Outside-the-batch report

Reading the window means reading confirmed Dutch that no one is reviewing
in this batch. Defects there ship unless someone mentions them, and noting
them costs little once the window has been read anyway. So when the window
shows any of the following, report it after the client-decision summary:

* **Untranslated gaps** — a segment with status *Not translated* (or an
  empty `NL`) and a blank `Batch` column. It stays empty after re-import
  unless it is added to a workfile. If the segment is in fact covered by a
  batch row that failed to match (a stripped placeholder, or two segments
  joined into one row), it is not a gap: it is already accounted for in
  that row's Notes, so leave it out.
* **Meaning errors** — the Dutch says something the English does not: a
  reversed comparison or quantity (*3 or more* → *3 of minder*), the wrong
  object (*Bicycles* → *motoren*), a lost negation, a dropped clause, a
  dropped hedge (*may be displayed* → *wordt weergegeven*).
* **House-term drift** — a confirmed segment rendering a term differently
  from the master list, the workfile terminology, the TM, or its own
  neighbours (*stuurwiel*
  where the section uses *stuur*; two Dutch names for one function).
* **Defects a reviewer would correct on sight** — de/het errors, doubled or
  garbled words, a content word repeated three times.

Give each item one line: segment number(s), the problem, and the correct
form where it is obvious. Put meaning errors and untranslated gaps first,
because they change what the reader receives; drift and grammar follow. If
a defect sits in an *Edited, unconfirmed* segment, say so, since the
translator may already be working on it.

The report covers what the window shows while you read it for the batch;
it is a by-product of that reading, not a separate audit, so a short list
is normal. If nothing in the window qualifies, omit the section rather than
writing "none".

The report is advisory. The context file stays read-only and the workfile
stays the sole delivery artefact: never edit or re-deliver a confirmed
segment on your own initiative, and never record these findings in the
Notes of workfile rows, which belong to their own segments.

A confirmed TM unit is changed only when the defect is real — a meaning
error, a lost hedge, a wrong term — never for preference; the user then
tells the client that the unit had to change. When the user accepts a
reported defect and asks for it to be finalised, return the corrected row
in the context file's own shape (same columns, only `NL` changed) in a
code block. Apply every rule of this skill to the corrected Dutch,
including Word Repetition. Follow it with a short list of what changed and
why, phrased so it can go straight into the client note.

Head the section exactly:
**Outside the batch (the context file is read-only, so nothing was changed)**

Reading the Reference Columns Correctly
---------------------------------------

Three traps recur in this client's workfiles.

**Capitalisation artefacts.** Dictionary keys and values arrive title-cased
by the extraction script: `{'Rear': 'Achter', 'Vehicle': 'Voertuig',
'If equipped': 'Indien aanwezig'}`. The *lexical content* is binding; the
*casing* is not. Dutch running text keeps these lowercase mid-sentence —
*achter*, *voertuig*, *(indien aanwezig)*. Preserve capitals only for
genuine proper nouns and brand strings (SUBARU, SUBARU Care, ALL AUTO
(ECO), PCS, eAxle) and at sentence start.

**Single-word entries are glosses, not substitutions.** `'High': 'Hoog'`,
`'On': 'Aan'`, `'Off': 'Uit'` describe the concept, not the surface form
required in the sentence. *the possibility of a collision is high* is
*is de kans op een aanrijding groot*, not *…is hoog*. Apply the term where
it is genuinely the head word; otherwise use the idiomatic Dutch and note
`TERM-CONTEXT:`.

**Fuzzy pre-fills inherit upstream corruption.** The `[FUZZY nn%]` string in
column 2 was produced against the *similar* English sentence quoted in
Notes, sometimes after a botched term substitution. Two observed failures:

* `0.700 kg (1.54 lb.)` → pre-fill `0,720 kg` — wrong value, taken from a
  neighbouring segment. Correct: `0,700 kg` (the imperial conversion is
  dropped under the Measurement Localisation rule below, so here the
  pre-fill's omission happens to be right for the wrong reason).
* *…send an emergency call to the response center* → pre-fill
  *…een SUBARU Care-melding naar het responsecentrum te sturen* — the
  upstream source had *emergency call* overwritten by *SUBARU Care*.
  Correct: *een noodoproep naar het responscentrum te sturen*.

Procedure for every fuzzy row: diff the real English source (col 1) against
the quoted fuzzy source in Notes, translate the delta, restore anything the
pre-fill dropped **except material the Measurement Localisation rule removes**,
verify every number and unit against col 1, strip the `[FUZZY nn%]` tag, and
mark `FUZZY-REFINED`.

Style Rules (Dutch, owner's-manual register)
---------------------------------------------

* **No translationese.** The Dutch must read as if originally written by a
  native technical author. Fidelity is to meaning and function, never to the
  English word order, rhythm, or sentence boundaries — restructure freely.
  Test each string: would a Dutch manual writer, given only the meaning,
  produce this sentence? If the English shows through, rewrite.
* **Address the reader with *u***; never *je*. Instructions take the
  imperative (*Druk op…*, *Zorg ervoor dat…*, *Raadpleeg…*).
* **No future tense.** English *will* does not survive into Dutch technical
  text. Use the present for behaviour and facts: *the light will illuminate*
  → *het lampje gaat branden* / *brandt*, not *zal branden*. *Zal/zullen*
  appears only in genuine conditionals where the present would be wrong.
* **Keep the source's modality.** A hedge in the source (*may be
  displayed*, *may not operate*) tells the reader what the system does not
  guarantee; stating it as fact (*wordt weergegeven*) is a meaning error,
  not a style choice, and in safety text it overstates the system. Render
  *may* as *kan* or *mogelijk*, and do not hedge what the source states
  flatly. A doubled English hedge may collapse into one Dutch hedge:
  *operation may be possible* → *is werking mogelijk*.
* **Measurement localisation.** `reference/units.csv` is the client's own
  EN→NLD unit table and governs every measurement, number and quotation
  mark. Read it whenever a row contains a figure. The rules it encodes:
  * **Imperial is deleted, never converted.** mph, mile, lb., °F, in., ft.,
    qt., gal., psi, cu.in., lbf, ft·lbf go, whether standing alone or in a
    parenthesis beside the metric value: `0.700 kg (1.54 lb.)` → `0,700 kg`;
    `100 km/h (62 mph)` → `100 km/h`.
  * **Metric alternates are kept, and some are added.** Force `N (kgf, lbf)`
    → `N (kp)`; torque `N·m (kgf·m, ft·lbf)` → `N·m (kp·m)`; pressure
    `kPa (kgf/cm2 or bar, psi)` → `kPa (kgf/cm2 of bar)` — note *or* → *of*.
  * **Rotation takes an alternate the English lacks**: `rpm` → `rpm (min-1)`.
    Never *omw/min*, which belongs to a different client.
  * **Volume is lowercase**: `L` → `l`.
  * Keep the metric unit the source uses (`t` stays `t`); never convert
    between metric units. Where imperial is the *only* measurement given,
    convert to metric and show the conversion in the note.
  * Mark every such row `LOCALISED:`.
* **Numbers.** Decimal comma: `0.1` → `0,1`, `0.700 kg` → `0,700 kg`.
  Grouping mirrors the source's own choice: `1000` stays `1000` and `10000`
  stays `10000`, but `1,000` → `1.000` and `10,000` → `10.000`.
  `No.` → `Nr.`, `NO.` → `NR.`, preserving the source's spacing: `No.1` →
  `Nr.1`, `No. 1` → `Nr. 1`.
* **Punctuation.** Curly double quotes `“ ”` and the typographic apostrophe
  `’`; never their straight ASCII forms. No space before a colon.
* **Unit spacing**: space before the unit (`2 seconden`, `200 kPa`, `20 °C`);
  follow the Terminology/TM column where it shows a client convention.
* **Compounds close up**: *aircosysteem*, *stuurwielschakelaar*,
  *batterijpreconditionering*. Hyphenate only after an acronym, digit,
  brand, or vowel clash: *PCS-waarschuwingslampje*, *12 V-accupool*,
  *3D-kaart*, *SUBARU Care-abonnees*, *eco-airconditioningsmodus*.
* **Preserve byte-identically**: brand and system names with original casing
  (SUBARU, SUBARU Care, eAxle, ALL AUTO (ECO), PCS, RCD, POI, GPS as *gps*
  per glossary), model and part codes, footnote asterisks (`stoelverwarming*`),
  placeholders and cross-reference markers (`[*]`, `“”`), and any literal
  on-screen button or menu text carried untranslated in the TM.
* **Acronym expansions follow the TM's order.** Where TM gives
  *PCS (botswaarschuwingssysteem)*, keep that order rather than mirroring
  the English *Pre-Collision System (PCS)*.
* **de/het accuracy** is checked on delivery: *het voertuig*, *de
  schakelaar*, *het lampje*, *de accu*, *de batterij*, *het scherm*.

### Anglicisms and Calques (reject on sight)

| English | Wrong | Right |
| --- | --- | --- |
| make sure that | maak zeker dat | zorg ervoor dat |
| the system is designed to | het systeem is ontworpen om | het systeem stuurt … aan / het systeem is bedoeld om |
| will operate | zal werken | werkt / wordt aangestuurd |
| is high (probability) | is hoog | is groot |
| press and hold | druk en houd vast | houd … ingedrukt |
| if equipped | indien uitgerust | indien aanwezig |
| when the power switch is turned to ON | wanneer de contactschakelaar naar AAN wordt gedraaid | wanneer het contact wordt ingeschakeld |
| response center | responsecentrum | responscentrum |
| approximately 5 seconds | ongeveer 5 seconden (ok) — but never *circa 5 seconds* | ongeveer 5 seconden |

Also reject: English word order surviving into Dutch (verb-second and
verb-final violations), stacked prepositional strings where a compound is
idiomatic, and *deze* used where Dutch would repeat the noun.

### Word Repetition Within a Segment

English tolerates repeating a content word inside one sentence; Dutch reads
it as clumsy, and it is corrected by hand on delivery. Remove it at source.

**Scope: within one segment only.** Repetition *across* segments is usually
correct and often mandatory — the same term must render identically
everywhere, which is what the Consistency Pass enforces. Never synonymise a
term to avoid repeating it in a neighbouring segment. Where the two pulls
conflict, consistency wins and the repetition stands.

Order of preference, strictest first:

1. **Keep one instance; eliminate the other.** Elimination beats
   synonymy every time. Try each of these against every repeated stem
   before concluding that the repetition has to stay — reaching for
   `DEDUP: retained` while an untried elimination exists is the common
   failure here:
   * gapping — of a verb (*ontgrendel eerst de portieren en daarna de
     aansluiting*), a preposition (*door een dealer, een reparateur of
     een hersteller*), or a head noun across coordinated modifiers
     (*een door SUBARU erkende of een andere betrouwbare reparateur*)
   * compounds — *laad- en ontlaadproces*, not *laadproces en
     ontlaadproces*
   * pronominal adverbs — *ervan*, *daarvan*, *daarmee*, *daarop*
   * relative subordination with *die/dat*, collapsing two clauses into one
   * zero anaphora where Dutch permits it and English does not
2. **Synonymise only if elimination fails**, and only on non-terminological
   words. A word used consistently across the project is not thereby a
   bound term: if it appears in neither `reference/terminology.csv` nor
   the row's own Terminology column, it is ordinary vocabulary and may be
   varied. Watch for synonyms that carry a regional marker or collide
   with a false friend in a neighbouring language of the review chain.
3. **Restructure the sentence** if neither works. Fidelity is to meaning,
   never to the English sentence boundary.

**Where the repetition sits matters as much as how often it occurs.** Two
instances falling close together, and especially in the closing phrase of
a sentence, read as clumsy; the same two spread across separate clauses
usually do not. Judge by weight and position, not by a word count — and
prioritise the end of the sentence, where Dutch expects the weight to
settle.

**Terminology is untouchable by default.** A term may be replaced by an
anaphor (*deze*, *dit*, *ervan*) only when all three hold:

* the antecedent is the **nearest** preceding noun phrase;
* gender and number agree (*deze schakelaar*, *dit lampje*);
* **no competing noun phrase** stands between anaphor and antecedent.

If any one fails, leave the repetition. *Deze* reaching back past another
candidate noun is a defect, not a fix. Where the repetition survives
deliberately, say so in Notes — a `DEDUP: retained` line marks it as a
decision rather than an oversight, so it is not re-examined by hand.

**Approved exception: *auto* for the reader's own vehicle.** Apply the
binding term 'Vehicle' → *voertuig* strictly: the client has confirmed it
takes precedence over the house usage *auto* found in confirmed
neighbours, so that difference on its own is not raised as `HARMONISE:`.
The one sanctioned departure is for repetition. If applying the term would
put *voertuig* (or *voertuigen*) twice in one segment, and elimination
under step 1 fails or would lose the reference point, render the
occurrence that refers to the reader's own car as *auto* (*de auto*, *uw
auto*) and keep *voertuig* for the other vehicles. This does more than
avoid a repeat: *auto* marks the reader's car against the others, the same
split the confirmed text already makes.

* *Er zijn geen naderende voertuigen in de buurt van het voertuig* →
  *Er zijn geen naderende voertuigen in de buurt van de auto*
* *(uw voertuig kan de voorligger of het voertuig naast u volgen)* →
  *(uw auto kan de voorligger of het voertuig naast u volgen)*

If *voertuig* occurs only once in the segment, keep it; the exception
resolves a repetition and is not a route back to *auto* in general. If
every occurrence refers to another vehicle, the exception does not apply
and the ordinary rules above govern. Mark the row `DEDUP:` and say that
*auto* was used for the own vehicle as the approved synonym. TM units
stored before this rule may still repeat *voertuig*; apply the exception
anyway and mark the row `TM-ADAPTED:`.

Never let deduplication alter meaning, drop a qualifier, weaken a safety
instruction, or break a UI string that must match on-screen text. **When in
doubt, no change.**

### Settled Term Decisions

These were settled with the client's reviewer. Apply them without raising
`HARMONISE:` again.

**"Lane or course" (LDA, LTA, OAA).** The English *course* has three
senses in this manual, and each needs its own Dutch:

* **Road sense** — the car deviates from, or drives on, its *lane or
  course*. The course is the road itself, whose edge the manual's footnote
  defines (asphalt against grass or soil, a curb, a guardrail). Render
  *rijstrook of weg*, adding the article the sentence needs: *van de
  rijstrook of de weg afwijken*, *op een smalle rijstrook of weg*. This is
  the standing entry `lane or course,rijstrook of weg` in
  `reference/terminology.csv`. A footnote asterisk stays on the noun it
  follows in the source: `course*` → `weg*`.
* **Recognition sense** — the system recognises or detects a *lane or
  course*. What it sees are lines and edges, so render *rijstrookmarkering
  of wegrand*, and mark the displaced entry `TERM-CONTEXT:`.
* **Heading sense** — a vehicle *changes course*. Render *van koers
  veranderen*, which is correct and idiomatic. The standing entry is keyed
  on the whole phrase *lane or course* precisely so that it does not fire
  here; never add *course* alone to the terminology.

Rejected renderings, so they are not proposed again: *koers* for the road
sense (it means heading; older LDA units in the TM still carry it, so
override them and mark the row `FUZZY-REFINED:` or `TM-ADAPTED:`);
*rijbaan* (correct but stiff); *berm* (the verge beyond the edge, where the
car ends up rather than what it deviates from); and *wegrand* with
*afwijken van* (deviating from an edge means moving away from it — *wegrand*
works only with recognition or crossing verbs).

**"Object" (*object* or *voorwerp*).** The choice follows the sense, not
the chapter:

* ***object*** — anything the vehicle's sensors or systems detect, track or
  react to: the ADAS target, the parking-assist obstacle, the thing the
  sonar measures the distance to. *Wanneer het systeem vaststelt dat een
  gedetecteerd object zich van het voertuig heeft verwijderd*.
* ***voorwerp*** — a physical item that a person handles, places, hangs or
  inserts, or that gets in the way mechanically: things hung on the
  back-door handles, a pin in the power outlet, a bicycle carrier on the
  back door, something obstructing the seat. *Hang geen voorwerpen aan de
  handgrepen van de bagageklep*.

Two borderline cases are settled. Something touching or held near the
steering wheel is *voorwerp*: the system registers contact, not a detected
target (*Wanneer een ander voorwerp dan de hand van de bestuurder het stuur
raakt*). A small item under the rear bumper that falsely triggers the
hands-free back door is *voorwerp* too, since it is an accidental
obstruction, not a detection target (*Wanneer een klein dier of voorwerp
zoals een bal onder de achterbumper beweegt*).

The phrase-level forms are in the client's terminology list, so they reach
the workfile as binding `TERMS:` entries: *detectable object* →
*detecteerbaar object*, *detected object* → *gedetecteerd object*, *target
object* → *doelobject*, *moving object* → *bewegend object*. Bare *object*
deliberately has no entry, because a single binding rendering would be wrong
for one of the two senses; decide it by the rule above and do not mark it
`TERM-CONTEXT:`. *Static object* and *stationary object* are both
*stilstaand object* (plural *stilstaande objecten*), also in the
terminology list: it is by far the most frequent form across the manual,
and the few *statisch* renderings are a stray from earlier translators. TM
units that still carry *statisch* are overridden and marked `TM-ADAPTED:`;
*statisch* in a confirmed segment is drift for the Outside-the-batch
report.

A sensor-detected thing rendered as *voorwerp*, or a handled item rendered
as *object*, in a confirmed segment is house-term drift for the
Outside-the-batch report.

### Structural Patterns

* **Cross-reference**: *For details on X, refer to the [*]* → *Voor meer
  informatie over X raadpleegt u de [*]* (or *zie de [*]* per TM).
* **Warning/consequence**: state the instruction first, consequence second;
  *possibly leading to an accident* → *wat kan leiden tot een ongeval*.
* **Conditional safety line**: *If the system determines that…* → *Als het
  systeem detecteert dat…* — *detecteren/bepalen* per TM, never *beslist*.
* **Spec line**: nominal, no invented articles or verbs; unit and number
  formatting normalised to Dutch.
* **UI label**: short and nominal; no added articles, no sentence
  punctuation.

Workflow
--------

0. **Read the context file first**, if one is supplied. Locate every batch
   segment in it, note which rows failed to match, and read the confirmed
   Dutch around each one before translating anything. Jot down anything
   that belongs in the Outside-the-batch report as you pass it, rather than
   re-reading the window for it later.
1. **Integrity check the whole file first.** Look for collapsed `""`
   escapes, unparseable `TERMS:` dicts, rows with the wrong field count, and
   truncated sources. Do not guess at mangled reference data — translate on
   the intact evidence and mark `INPUT-ERR:` with a one-line description.
   Note duplicate English sources now; they drive the Consistency Pass.
2. **Per row**: read columns 3–6 and the row's neighbourhood in the context
   file, establish what the string is, apply the Priority Hierarchy, write
   the finished Dutch into column 2.
3. **Note** every non-trivial decision using the taxonomy below. Routine
   exact-terminology application needs only `TERM-APPLIED`.
4. **Consistency Pass** over the whole file: group repeated and near-repeat
   English sources and verify identical Dutch renderings. `FRESH` rows lack
   anchors and are where drift appears. Mark any row changed
   `CONSISTENCY:`.
5. **Repetition Pass**, after the Consistency Pass so that terminology is
   already locked and visibly off-limits. Read each finished Dutch string on
   its own and flag any content word occurring twice. Function words and
   terminology are exempt from the flag. Apply the Word Repetition procedure
   above and mark the row `DEDUP:`, whether the repetition was removed or
   deliberately kept.
6. **Output**: return the complete CSV — same delimiter, same row order, all
   six columns present, only **Translation** and **Notes** modified. Quote
   any field containing commas or quotes. Verify the file parses.
7. **Report** after the CSV: first the client-decision summary
   (`HARMONISE:` and `INPUT-ERR:` rows, plus any rows needing a split on
   re-import), then the Outside-the-batch report if the window gave it any
   content.

Notes Taxonomy (coded prefixes)
-------------------------------

| Prefix | Meaning |
| --- | --- |
| `TERM-APPLIED` | Exact terminology from cols 3/4 used as-is |
| `TERM-CONTEXT:` | Terminology present but inflected or displaced for idiom; state how |
| `TM-ADAPTED` | TM pair used but re-cast (state why) |
| `FUZZY-REFINED` | `[FUZZY nn%]` pre-fill repaired; state what was wrong |
| `LOCALISED:` | Imperial measurement dropped or converted; state which |
| `FRESH` | No terminology or TM; translated under skill rules |
| `CONSISTENCY:` | Changed in the Consistency Pass to match a sibling row |
| `CONTEXT:` | Decided on evidence from the context file; give the segment numbers |
| `DEDUP:` | Within-segment word repetition removed, or deliberately retained; state which and how |
| `HARMONISE:` | Conflict or source-side issue needing a client decision |
| `INPUT-ERR:` | Malformed reference data in this row; describe briefly |

`HARMONISE:` and `INPUT-ERR:` rows must also be summarised in a short list
after the CSV, so they can be raised with the client without re-scanning the
file. Where a context file was supplied, the Outside-the-batch report (see
The Context File) follows that summary.

Bundled Reference Files
-----------------------

Read these when a row's own columns are thin, or when checking consistency
across a batch. Workfile columns always outrank them.

| File | Contents | When to read |
| --- | --- | --- |
| `reference/terminology.csv` | Unaltered copy of the GitHub master list (about 2,000 EN→NL pairs, mandated and locally standardised; all binding) | Refresh from GitHub at the start of every batch (see The Master Terminology List); check every row and every window segment against it |
| `reference/translation-memory.csv` | Approved full-segment pairs | Sentence-level near-matches |
| `reference/patterns.csv` | Recurring phrase-level renderings | Cross-references, safety phrasing, boilerplate |
| `reference/units.csv` | Client EN→NLD unit, number and punctuation table | **Any row containing a figure, unit, `No.`, or quotation mark** |

A supplied context file is not one of these. It outranks the TM, pattern
and unit files for house terms and register, being drawn from the live
project. For terminology the master list outranks it, because the window
can carry legacy renderings from earlier translators.

Quality Gate (final check before delivery)
------------------------------------------

* ☐ Every binding terminology match applied, inflected with `TERM-CONTEXT:`, or escalated with `HARMONISE:`
* ☐ Batch and window checked against the master list (live copy if the fetch succeeded)
* ☐ No `[FUZZY nn%]` tags left in column 2
* ☐ Every fuzzy row diffed against col 1: numbers, units, parentheses, and dropped clauses restored
* ☐ No imperial units anywhere in column 2 (mph, mile, lb., °F, in., ft., qt., gal., psi, cu.in., lbf)
* ☐ Metric alternates present where `units.csv` requires them (kp, kp·m, min-1)
* ☐ Volume as `l`, rotation as `rpm (min-1)`, pressure parenthesis using *of*
* ☐ Decimal commas throughout; grouping mirrors the source; `No.` → `Nr.`
* ☐ Curly quotes `“ ”` and apostrophe `’`; no space before a colon
* ☐ No future tense; imperative used for instructions; *u* not *je*
* ☐ No anglicisms or calques from the table above
* ☐ Every source hedge (*may*, *can*) kept; nothing hedged that the source states flatly
* ☐ *Object* for sensor-detected things, *voorwerp* for handled or obstructing items, per Settled Term Decisions
* ☐ *Lane or course* rendered per Settled Term Decisions: road sense *rijstrook of weg*, recognition sense *rijstrookmarkering of wegrand*, heading sense *koers*
* ☐ No content word repeated within a segment, unless retained with a `DEDUP: retained` note
* ☐ Every anaphor used to eliminate a repetition has the nearest antecedent, agreeing gender and number, and no competing noun in between
* ☐ No translationese: every string passes the native-author test
* ☐ Compounds closed up; hyphens only after acronym, digit, brand, or vowel clash
* ☐ Brand, model, code, asterisk, and placeholder strings byte-identical to source
* ☐ de/het correct throughout
* ☐ Repeated English sources → identical Dutch
* ☐ Where a context file was supplied: every batch row located in it, house terms taken from confirmed neighbours, register matched to `Struct`, and unmatched rows marked `INPUT-ERR:`
* ☐ CSV parses; columns 1, 3, 4, 5 untouched
* ☐ Client-decision items summarised after the CSV
* ☐ Where the window showed untranslated gaps, meaning errors, term drift or on-sight defects in confirmed segments: Outside-the-batch report given, one line per item, severest first; context file untouched
