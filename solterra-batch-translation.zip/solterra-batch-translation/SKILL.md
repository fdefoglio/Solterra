---
name: "solterra-batch-translation"
description: "Translate Subaru Solterra owner's-manual and automotive UI content from English into Dutch using a six-column CSV workfile (English | Translation | Replacements | Terminology | Translation Memory | Notes)."
---

Solterra Localisation: English → Dutch
=====================================

Client: Subaru Solterra (battery-electric vehicle). Content: owner's manual,
multimedia/navigation UI, safety notices, spec lines.

Operating Model
---------------

This skill is **never used alone**. It is always paired with a workfile CSV
(`output.csv` or equivalent) whose columns carry all segment-specific data.
The workfile is the primary source of truth; the bundled reference files
supply the client's standing glossary where a row's columns are empty.

**Never import Dutch terminology from the Honda work into this client.** The
two clients diverge on core vocabulary (Solterra: *batterij*,
*tractiebatterij*; Honda: *accu*). Solterra terminology comes from the
workfile columns first, then the master list (`terminology.csv` on GitHub),
and nowhere else. See The Master Terminology List below.

The CSV Contract
----------------

Six columns, in order. Read all six per row before translating. A context
file may accompany it — see The Context File below.

**Where the files are.** The workfile is produced by `solterra.py next` in
the user's working folder (`C:\Temp\core_dep`, reached through the linked
computer). It sits beside `full_context.csv`, `batch_map.csv` (workfile row
→ Transit segment numbers) and `terminology.csv`. Work on them there, in
place. `solterra.py import` later writes column 2 into the Transit `.NLD`
by segment number, so the rules below are what make the import work.

**Rows are fixed.** Never add, remove, split, merge or reorder rows, and
never change column 1. `import` checks the workfile against
`batch_map.csv` row by row and refuses if they differ. Identical English
sentences have already been merged into one row, and `import` fills every
segment that row serves.

| Column | Content | Your obligation |
| --- | --- | --- |
| 1. English | Source string | Translate this, exactly as scoped |
| 2. Translation | Empty, or a `[FUZZY nn%]` pre-fill | **Your output goes here**; strip the tag |
| 3. Replacements | `TERMS: {...}` dict plus a `PATTERN: [...]` term list | Binding where the key matches the source |
| 4. Terminology | `"en" -> "nl"` pairs; same data as col 3 in display form | Binding |
| 5. Translation Memory | `en -> nl` pairs harvested from TM | Support only — adapt, never paste blindly |
| 6. Notes | Empty, or upstream fuzzy/mandatory remarks | Append your coded note (see Notes Taxonomy) |

An empty `TERMS: {}` means no terminology exists for the row: translate
fresh under this skill's style rules, check the master list for
a standing match, and mark the row `FRESH` in Notes.

`PATTERN: [Contactschakelaar] [Aan] [Indicatielampje]` is an unordered bag
of the same terms, **not a sentence skeleton**. Never build a sentence by
stringing the bracketed items together.

### Tag placeholders (double spaces)

Column 1 shows the segment as Transit shows it: inline tags (an icon, an
`<mmui>` UI label, a cross-reference) are removed, and each one that stood
between two words leaves a **double space** (`Touch  to display the mini
player.`). `import` puts each tag back at a double space in the Dutch, in
order, so the double spaces are load-bearing:

* The Dutch has **exactly as many double spaces as column 1**: no more, no
  fewer, and no double space anywhere else.
* Put each one where that tag belongs in the Dutch sentence, in the same
  order as in the English: `Touch  to display the mini player.` → `Tik op
  om de miniplayer weer te geven.`
* Where the tag ends the clause in Dutch, put the double space before the
  punctuation: `Touch  tab.` → `Tik op het tabblad  .` (`import` closes up
  the space before `.`, `,`, `;`, `:`, `)`, `!`, `?`).
* Read `full_context.csv` to see what each gap holds (a UI label, an icon),
  so the Dutch around it is right: *op* before a button, *het tabblad*
  before a tab name.
* A tag glued to a word or at the very start or end (`/ switches`,
  `Bluetooth® device`) leaves no double space and cannot be placed
  automatically: translate the visible text, reproduce column 1's
  punctuation around the gap (`/-schakelaars`), and say in Notes where the
  tags go. `import` lists such segments in `manual_segments.csv` and adds them
  to the running `manual_todo.csv` for the user; the file is still marked
  done. Log each one in the Decision Log as *Manual Transit*.
* If the tags in Dutch must come in a different order from the English,
  keep the English order of double spaces and flag the row `HARMONISE:` so
  the user can fix it in Transit.

### Priority Hierarchy (strict)

1. **Context validity** — the translation must be correct for what the
   string *is* (UI label, caption, warning, spec line). A terminology match
   that produces nonsense in context is escalated with `HARMONISE:`, not
   applied silently.
2. **Replacements / Terminology columns and the master list** — exact
   matches are binding.
3. **Confirmed neighbouring segments** in the context file, where one is
   supplied (see below). A neighbour outranks the TM, but not the master
   list: where the list has an entry, a neighbour that differs is legacy
   drift.
4. **Translation Memory column**, then `reference/translation-memory.csv`.
5. **Patterns** — `reference/patterns.csv` and the structural patterns below.
6. **Fuzzy pre-fill / machine output** — lowest. A draft to be repaired,
   never evidence of correctness.

Where levels conflict, apply the higher level and record the conflict in
Notes with the `HARMONISE:` prefix.

The Master Terminology List
---------------------------

The master list is `terminology.csv` on GitHub (`fdefoglio/Solterra`):
every field quoted, CRLF line endings. The user keeps a local copy in the
working folder, and `reference/terminology.csv` is an older fallback. It holds client-
mandated terms and terms standardised locally by the user; only the user's
CAT tool shows which is which. Locally standardised terms are later
approved and mandated by the client, so treat **every entry as binding**.
It is the only terminology list for this client.

**Refresh before a batch.** Fetch the live list first, because the user
adds to it between batches. Where the repository is attached to the
session (`fdefoglio/Solterra`), pull it; otherwise download it:

```bash
curl -sSL -o /tmp/terminology.csv https://raw.githubusercontent.com/fdefoglio/Solterra/main/terminology.csv
```

If the download succeeds and parses as two columns under an
`english,dutch` header, use it in place of the bundled copy. If it fails, use
the user's local `terminology.csv`, else the bundled copy, and say so in one
line of the reply, so the user knows newer entries may be missing. Rows that
do not parse into two columns are skipped and listed for the user to fix on
GitHub. Read the list; never rewrite, re-quote or repair existing rows, so
the copies stay identical to GitHub. Where the user's local
`terminology.csv` differs from GitHub, GitHub wins: say so in one line.

**Adding terms.** When a batch settles a term the list does not have (a
UI label, a feature name, a compound used across rows), add it in the same
turn, in both places:

1. Append it to the user's local `terminology.csv`: every field quoted,
   CRLF, UTF-8, skipping any key already present (case-insensitive).
2. Append the same rows to `terminology.csv` in the repository, then commit
   and push to `main`, with the terms named in the commit message. If the
   repository is not attached, attach it with push access first; the user
   approves that once per chat.
3. Name the added terms in one bullet under **Client decisions**, and say
   that GitHub was updated. If the push fails, say so in that bullet and
   list the rows for the user to add by hand.

Add only terms the batch actually settled. A rendering flagged
`HARMONISE:` waits until the user confirms it.

**Matching.** Match case-insensitively on whole words, longest entry
first. A match survives inflection and an inserted article (*het
voorgaande voertuig*, *afstand tot de voorligger*); neither is a
deviation.

**Legacy TM.** Several translators have worked on this project over the
years, so confirmed segments can deviate from the list. The list decides:

* If the list has an entry and a confirmed segment in the window uses a
  different form, report it as house-term drift in the Outside-the-batch
  report, whatever the segment's status.
* If a confirmed segment matches the list, it is correct. Do not report
  the entry's wording as a defect, even where it reads unusually (*de
  zijradarsensoren vóór*); the user has already settled it.
* If an entry itself looks wrong (a meaning error, a truncated or
  malformed row), raise it as a question for the user rather than a
  defect, since it may be mandated.
* If the list has no entry and the TM or the window shows competing
  renderings, propose one standard with its evidence (TM majority, the
  pattern of related list entries, a quick web check for an OEM form) and
  say which segments would change. The user adds the agreed form to the
  list.

**Normalisation deliverable.** When the user asks to normalise segments to
the list or to an agreed standard, return a `"current","to_replace"` CSV
in a code block, one full segment string per row, so each replacement is
unambiguous in the CAT tool. Apply every rule of this skill to each
`to_replace` string, including Word Repetition: a replacement that
introduces a repeat is recast. Follow it with a short list of what changed
and why, phrased for the client note, and name any matching segments
deliberately left unchanged (for example, a term bound by a different
entry).

The Context File
----------------

The workfile holds only the untranslated segments of one Transit file.
`full_context.csv`, written alongside it by `solterra.py next`, is the
**whole file** in **document order**: every segment, with the confirmed
Dutch above and below each batch segment. It is rebuilt from the Transit
`.ENU`/`.NLD` pair each time.

**Read it before translating any row, not as a lookup afterwards.** It is
read-only: nothing is ever written back to it. Fixes to confirmed segments
reach Transit through `context_fixes.csv` or an XML snippet (see Fixing
reported defects below), never through the context file.

| Column | Content |
| --- | --- |
| `RowIndex` | Transit segment number (`SegID`); document order. These are the segment numbers used in Notes, the outside-the-batch report and `batch_map.csv` |
| `English` | Source, **with the raw Transit tags** (`<Tag …>`, `<FontTag …>`, `<mmui>` labels): this is where you see what each double space in the workfile stands for |
| `Translation` | Target with its tags. For an untranslated segment it repeats the English |
| `Status` | `Translated` (confirmed, house style), `Edited, unconfirmed` (changed, not yet confirmed: weaker evidence than *Translated*), blank (not translated: the batch's own segments, or ones still to do). A ` (legacy)` suffix marks a reference translation (blue in Transit; see Legacy segments) |

Where `Translation` repeats `English` and `Status` is blank, the segment is
untranslated, not a defect.

`batch_map.csv` (`Row,SegIDs,English`) links each workfile row to its
segment number(s). A row serving several segments lists them separated by
`;` (`30;38`).

Older batches may come with a windowed `context_T1.csv` (`Seg`, `Struct`,
`Status`, `EN`/`NL`, `Batch`, with `...` gap rows); read it the same way,
and never treat rows either side of a gap as neighbours.

### What to take from it

* **House terms.** A confirmed neighbour outranks the TM column for
  terminology and register, because it is this document, this section.
  It does not outrank the master list: where the list has an entry, follow
  the list and report the neighbour as drift.
  Where a *full-segment* TM pair and a confirmed neighbour disagree on a
  whole string, apply the higher level but raise `HARMONISE:` rather than
  overriding silently.
* **Register and structure.** The tags in the `English` column (and
  `Struct` where a windowed file has it) say whether a string is a table
  cell, a list item, a heading or a footnote. Match the siblings: list
  items that are conditions stay plain present-tense statements; table
  cells stay nominal and article-free.
* **Referents.** What the previous segment left standing decides whether
  an anaphor is safe in this one — see the Word Repetition rules.
* **Revision traps.** A near-identical confirmed segment beside a batch
  segment is often the *previous revision* of the same sentence. Its Dutch
  is correct for the old English and is frequently what the fuzzy pre-fill
  was built from. Translate the delta and raise `HARMONISE:` if both
  versions now stand in the same list.
* **Stored form over earlier delivery.** Where the TM column or a fuzzy
  source shows a unit stored differently from what an earlier batch
  delivered, the reviewer has edited it since. Follow the stored form for
  sibling segments and say so under `CONSISTENCY:`.

Note the evidence in the row's Notes with the `CONTEXT:` prefix, giving the
segment numbers relied on.

### Limits

* Locate each row through `batch_map.csv` (its segment numbers), not by
  matching text: the English column of the context file carries tags, and
  column 1 does not. A cross-reference reduced to `()` or a button label to
  `“”` is extraction, not an error: reproduce it exactly as column 1 gives
  it. Mark `INPUT-ERR:` only for real damage (truncated source, mangled
  reference columns).
* A row serving several segments (`30;38` in `batch_map.csv`) is filled in
  all of them on import; it needs no note and no client-decision bullet.
* One Transit segment may hold **two** sentences. Translate it as one row;
  never split it. `SPLIT:` is only for the rare row that has to be split
  in Transit, and says where.
* A windowed context file is counted in segment numbers, not structure,
  so it can cut a table in half. Absence of evidence in the window is not
  evidence of absence.

### Outside-the-batch report

Reading the window means reading confirmed Dutch that no one is reviewing
in this batch. Defects there ship unless someone mentions them, and noting
them costs little once the window has been read anyway. So when the window
shows any of the following, report it after the client-decision summary:

* **Meaning errors** — the Dutch says something the English does not: a
  reversed comparison or quantity (*3 or more* → *3 of minder*), the wrong
  object (*Bicycles* → *motoren*), a lost negation, a dropped clause, a
  dropped hedge (*may be displayed* → *wordt weergegeven*).
* **House-term drift** — a confirmed segment rendering a term differently
  from the master list, the workfile terminology, the TM, or its own
  neighbours (*stuurwiel*
  where the section uses *stuur*; two Dutch names for one function).
* **Defects a reviewer would correct on sight** — de/het errors, doubled or
  garbled words, a content word repeated three times, a missing comma
  between clauses.
* **Source-side faults** — the Dutch mirrors the English, but the English or
  its markup is broken: an unresolved placeholder such as `(→P.###)` where
  neighbouring segments carry a real `<xref>`, or a typo in the English that
  will reach print. These cannot be fixed on the Dutch side; report them so
  they can go to the client as a query.

Give each item one line: segment number(s), the problem, the correct form,
and how it was handled (see below). Put meaning errors first, because they
change what the reader receives; drift and grammar follow. Untranslated
segments in the window are not reported: the user tracks them in the CAT
tool, and they reach a later workfile. If a defect sits in an *Edited,
unconfirmed* segment, say so, since the translator may already be working
on it.

The report covers what the window shows while you read it for the batch;
it is a by-product of that reading, not a separate audit, so a short list
is normal. Before omitting it, check every window segment that is not
*Not translated* against the categories above, including the user's own
*Edited, unconfirmed* segments. Those hold the user's edits since the last
delivery, and they are where drift from this batch's own decisions appears
most often: a term the batch standardised still in its old form in an
edited neighbour, or an element dropped in a rewording. If nothing
qualifies after that check, omit the section rather than writing "none".

Never record these findings in the Notes of workfile rows, which belong to
their own segments. A confirmed TM unit is changed only when the defect is
real — a meaning error, a lost hedge, a wrong term, an on-sight defect —
never for preference; the user then tells the client that the unit had to
change.

### Fixing reported defects (same turn, no confirmation needed)

A target-side defect (meaning error, lost hedge, drift against the master
list, on-sight defect) is fixed **in the same turn as the report**, without
asking the user first. How depends only on whether the segment has inline
tags:

* **Untagged segment, legacy or not:** append a row to `context_fixes.csv`
  in the working folder (build it as set out in the Resolution Map), so
  `solterra.py import` applies it with this file. `replace_segments.py`
  rewrites only the text inside `<Seg>…</Seg>` and never touches `Data`,
  so a legacy segment stays blue. Log it as `Decision`, `Done`. This is
  the default; do not offer it as an option or wait for approval.
* **Tagged legacy segment:** deliver an XML snippet as set out under Legacy
  segments: the inner text in its own `xml` code block in the reply, the
  whole `<Seg>` saved as `manual_fix_<fileid>_seg<n>.xml`. The user
  replaces it by hand. Log it as `Manual Transit`, `Open`.
* **Tagged segment that is not legacy:** the same XML inner-text snippet
  (`replace_segments.py` skips tagged rows). Log it as `Manual Transit`,
  `Open`.

Not fixed, only reported: open choices the user has not settled (a style
split such as *Als* against *Wanneer*, a proposed standard not yet in the
list), logged `Internal (Frans)`, `Open`; and source-side faults, logged
`Client query`, `Open`. These are resolved by the Resolution Map when the
user accepts or decides them.

Head the section exactly:
**Outside the batch**

End each line with how it was handled: `→ context_fixes.csv`,
`→ XML snippet below`, or `→ not changed (your decision)` /
`→ client query`. Put the XML snippets after the section, one code block
per segment, each headed by its file and segment number.

### Legacy segments (blue in Transit)

A segment labelled `(legacy)` in `full_context.csv` came from earlier
reference material, not from the user. In the `.NLD` its `Data`
attribute carries the reference path `…\REF\…` (for example
`D:\STAR\Shintec\OM\REF\DITA\Navi\NLD\Navi_NLD`), the origin codes
`U+EA0D` and `U+F50A`, and an earlier translator and date (Rik Schraag,
Arno de Jong, 2022–2023). Transit shows these segments in blue. If the
user re-entered one in the CAT tool, its colour would change and confuse
the client's system, so a legacy segment is fixed **only in the XML**,
never retyped in the CAT tool, with `Data` left untouched.

How the fix is delivered (in the same turn as the report) depends on
whether the segment has inline tags:

* **Untagged legacy segment:** a `context_fixes.csv` row, written
  straight away. `replace_segments.py` rewrites only the text inside
  `<Seg>…</Seg>` and never touches `Data`, so the colour stays blue: the
  same result as the user's own XML edit. Log it as `Decision`, `Done`.
  Never hand an untagged legacy fix to the user as a snippet.
* **Tagged legacy segment** (`replace_segments.py` skips tagged rows): an
  XML snippet, the only kind of fix that reaches the user, as follows.

1. Read the segment's raw `<Seg SegID="n" Data="…">…</Seg>` from the
   working copy of the `.NLD` (in `work_dir`, UTF-16).
2. Build the corrected inner text: change only the defect, keep every
   tag byte for byte.
3. In the reply, give the corrected **inner text only** (everything
   between the opening tag and `</Seg>`) in its own `xml` code block,
   apart from the rest of the reply, and tell the user to replace only
   that part. Never ask the user to copy the opening tag from the chat:
   `Data` holds private-use control characters that a browser drops,
   which would lose the status and colour.
4. Also save the whole corrected `<Seg>`, original `Data` intact, as
   `manual_fix_<fileid>_seg<n>.xml` (UTF-16, like the `.NLD`) in the
   working folder, and name the file in the reply.
5. Log it in the Decision Log as `Manual Transit`, `Open`, with the
   corrected text in `applied`.

The legacy rule applies only to segments outside the batch: the batch's
own rows are untranslated and go through the workfile as usual.

### Resolution Map (resolving reported items)

Use this map for the same-turn fixes above, and every time the user
accepts or asks to resolve items that were only reported (*accept*,
*resolve them*, *Out: CSV block {'current','to_replace'}*), so that each
resolution has the same shape.

1. **Scope.** Take every item in the most recent Outside-the-batch report,
   plus any item the user adds. Items from earlier batches are reopened only
   when the user names them.
2. **Triage.** Sort each item into one of three kinds:
   * *Target-side defect* (meaning error, lost hedge, drift, on-sight
     defect): it gets a CSV row (untagged) or an XML snippet (tagged).
   * *Open choice the user has not settled* (for example *Als* against
     *Wanneer* across one list): once the user accepts it, apply the
     majority or house form, give it a CSV row, and say in its bullet that
     the majority was followed.
   * *Source-side fault* (the Dutch already mirrors the English; the fault
     is in the source or its markup, such as `(→P.###)`): no CSV row. List
     it after the bullets as a client query.
3. **Build each row.**
   * `current` is copied byte for byte from the context file's `NL`: the
     full segment, with inline tags, curly quotes and trailing spaces, so
     the CAT search finds it.
   * `to_replace` changes only the defect. Any other edit the user has made
     to that segment stays (a changed conjunction, a rewording).
   * Apply every rule of this skill to `to_replace`, including the master
     list and Word Repetition.
   * One segment per row. The same defect in several segments gets one row
     per segment.
   * Order the rows as the report ordered them: meaning errors first.
4. **Workfile rows already entered.** When a delivered workfile row is
   revised after the user has entered it in the CAT tool, give it a row too:
   `current` is the Dutch as delivered, `to_replace` the revision.
5. **Reply shape** (when resolving on request). The reply contains these
   parts, in this order, and nothing else:
   1. the CSV (tagged segments excluded: they take an XML inner-text
      snippet, as set out under Legacy segments): written to
      `context_fixes.csv` in the user's working folder (header
      `"current","to_replace"`, every field quoted, UTF-8, CRLF), so
      `solterra.py import` applies it; if a `context_fixes.csv` is already
      there, append to it. Where the folder is out of reach or the user asks
      for it in chat, give it in a code block instead. Give each tagged
      segment's inner text in its own `xml` code block after the bullets,
      for the user to replace by hand in Transit;
   2. one bullet per row, or per group of rows with the same change:
      `* **5153:** what changed and why`, one or two sentences, phrased so
      it can go straight into the client note;
   3. when there are source-side faults: one short paragraph naming the
      segments and saying why no replacement is possible, framed as a
      client query.

   No verdict line, no recap of the report. When the CSV went to the file,
   end with its name in backticks: `context_fixes.csv`.

Reading the Reference Columns Correctly
---------------------------------------

Three traps recur in this client's workfiles.

**Capitalisation artefacts.** Dictionary keys and values arrive title-cased
by the extraction script: `{'Rear': 'Achter', 'Vehicle': 'Voertuig',
'If equipped': 'Indien aanwezig'}`. The *lexical content* is binding; the
*casing* is not. Dutch running text keeps these lowercase mid-sentence —
*achter*, *voertuig*, *(indien aanwezig)*. Preserve capitals only for
genuine proper nouns and brand strings (SUBARU, SUBARU Care, ALL AUTO
(ECO), PCS, eAxle) and at sentence start.

**Single-word entries are glosses, not substitutions.** `'High': 'Hoog'`,
`'On': 'Aan'`, `'Off': 'Uit'` describe the concept, not the surface form
required in the sentence. *the possibility of a collision is high* is
*is de kans op een aanrijding groot*, not *…is hoog*. Apply the term where
it is genuinely the head word; otherwise use the idiomatic Dutch and note
`TERM-CONTEXT:`.

**100% TM rows lose their double spaces.** A row noted `100% TM MATCH -
Exact` arrives with the stored Dutch in column 2. The TM collapses
whitespace, so for a tagged segment the double spaces are gone. Check
every exact row against column 1: restore the double spaces where the tags
belong, apply the master list and the style rules as for any row, and note
`TM-ADAPTED:` if anything changed (`TERM-APPLIED` alone otherwise).

**Fuzzy pre-fills inherit upstream corruption.** The `[FUZZY nn%]` string in
column 2 was produced against the *similar* English sentence quoted in
Notes, sometimes after a botched term substitution. Two observed failures:

* `0.700 kg (1.54 lb.)` → pre-fill `0,720 kg` — wrong value, taken from a
  neighbouring segment. Correct: `0,700 kg` (the imperial conversion is
  dropped under the Measurement Localisation rule below, so here the
  pre-fill's omission happens to be right for the wrong reason).
* *…send an emergency call to the response center* → pre-fill
  *…een SUBARU Care-melding naar het responsecentrum te sturen* — the
  upstream source had *emergency call* overwritten by *SUBARU Care*.
  Correct: *een noodoproep naar het responscentrum te sturen*.

Procedure for every fuzzy row: diff the real English source (col 1) against
the quoted fuzzy source in Notes, translate the delta, restore anything the
pre-fill dropped **except material the Measurement Localisation rule removes**,
verify every number and unit against col 1, strip the `[FUZZY nn%]` tag, and
mark `FUZZY-REFINED`.

Style Rules (Dutch, owner's-manual register)
---------------------------------------------

* **No translationese.** The Dutch must read as if originally written by a
  native technical author. Fidelity is to meaning and function, never to the
  English word order, rhythm, or sentence boundaries — restructure freely.
  Test each string: would a Dutch manual writer, given only the meaning,
  produce this sentence? If the English shows through, rewrite.
* **Prefer the active voice (judgment check).** A passive that mirrors the
  English is one of the commonest signs of translationese in this manual,
  and a sentence that shows it must be recast. For every passive in a
  finished string, ask whether a clear agent exists — the reader (*u*),
  the system, or a named device (*de rijrecorder*, *het scherm*) — and
  whether the active reads better. If both hold, recast:
  * *Als dit niet uit het beeld kan worden opgemaakt* → *Als u dit niet
    uit het beeld kunt opmaken*
  * *wordt een botsing mogelijk niet correct gedetecteerd* → *detecteert
    de rijrecorder een botsing mogelijk niet correct*
  * *wanneer de 12V-batterij wordt losgekoppeld* (by an accident) →
    *wanneer de 12V-batterij loskomt*; an intransitive verb is often the
    cleanest active form when nobody acts deliberately.

  Keep the passive when the agent is unknown or irrelevant (*Het scherm
  wordt weergegeven* in a list of display states), when recasting would
  break a short UI string or label, in legal and disclaimer text where the
  impersonal register is deliberate, and when the only active subject
  would be *je* or an invented *men*. Recasting never drops a hedge: carry
  *kan* or *mogelijk* into the active sentence. Mark every recast row
  `ACTIVE:` in Notes.
* **Address the reader with *u***; never *je*. Instructions take the
  imperative (*Druk op…*, *Zorg ervoor dat…*, *Raadpleeg…*).
* **No future tense.** English *will* does not survive into Dutch technical
  text. Use the present for behaviour and facts: *the light will illuminate*
  → *het lampje gaat branden* / *brandt*, not *zal branden*. *Zal/zullen*
  appears only in genuine conditionals where the present would be wrong.
* **Keep the source's modality.** A hedge in the source (*may be
  displayed*, *may not operate*) tells the reader what the system does not
  guarantee; stating it as fact (*wordt weergegeven*) is a meaning error,
  not a style choice, and in safety text it overstates the system. Render
  *may* as *kan* or *mogelijk*, and do not hedge what the source states
  flatly. A doubled English hedge may collapse into one Dutch hedge:
  *operation may be possible* → *is werking mogelijk*.
* **Measurement localisation.** `reference/units.csv` is the client's own
  EN→NLD unit table and governs every measurement, number and quotation
  mark. Read it whenever a row contains a figure. The rules it encodes:
  * **Imperial is deleted, never converted.** mph, mile, lb., °F, in., ft.,
    qt., gal., psi, cu.in., lbf, ft·lbf go, whether standing alone or in a
    parenthesis beside the metric value: `0.700 kg (1.54 lb.)` → `0,700 kg`;
    `100 km/h (62 mph)` → `100 km/h`.
  * **Metric alternates are kept, and some are added.** Force `N (kgf, lbf)`
    → `N (kp)`; torque `N·m (kgf·m, ft·lbf)` → `N·m (kp·m)`; pressure
    `kPa (kgf/cm2 or bar, psi)` → `kPa (kgf/cm2 of bar)` — note *or* → *of*.
  * **Rotation takes an alternate the English lacks**: `rpm` → `rpm (min-1)`.
    Never *omw/min*, which belongs to a different client.
  * **Volume is lowercase**: `L` → `l`.
  * Keep the metric unit the source uses (`t` stays `t`); never convert
    between metric units. Where imperial is the *only* measurement given,
    convert to metric and show the conversion in the note.
  * Mark every such row `LOCALISED:`.
* **Numbers.** Decimal comma: `0.1` → `0,1`, `0.700 kg` → `0,700 kg`.
  Grouping mirrors the source's own choice: `1000` stays `1000` and `10000`
  stays `10000`, but `1,000` → `1.000` and `10,000` → `10.000`.
  `No.` → `Nr.`, `NO.` → `NR.`, preserving the source's spacing: `No.1` →
  `Nr.1`, `No. 1` → `Nr. 1`.
* **Punctuation.** Curly double quotes `“ ”` and the typographic apostrophe
  `’`; never their straight ASCII forms. No space before a colon.
* **Unit spacing**: space before the unit (`2 seconden`, `200 kPa`, `20 °C`);
  follow the Terminology/TM column where it shows a client convention.
* **Compounds close up**: *aircosysteem*, *stuurwielschakelaar*,
  *batterijpreconditionering*. Hyphenate only after an acronym, digit,
  brand, or vowel clash: *PCS-waarschuwingslampje*, *12 V-accupool*,
  *3D-kaart*, *SUBARU Care-abonnees*, *eco-airconditioningsmodus*.
* **Preserve byte-identically**: brand and system names with original casing
  (SUBARU, SUBARU Care, eAxle, ALL AUTO (ECO), PCS, RCD, POI, GPS as *gps*
  per glossary), model and part codes, footnote asterisks (`stoelverwarming*`),
  placeholders and cross-reference markers (`[*]`, `“”`), and any literal
  on-screen button or menu text carried untranslated in the TM.
* **Acronym expansions follow the TM's order.** Where TM gives
  *PCS (botswaarschuwingssysteem)*, keep that order rather than mirroring
  the English *Pre-Collision System (PCS)*.
* **de/het accuracy** is checked on delivery: *het voertuig*, *de
  schakelaar*, *het lampje*, *de accu*, *de batterij*, *het scherm*.

### Anglicisms and Calques (reject on sight)

| English | Wrong | Right |
| --- | --- | --- |
| make sure that | maak zeker dat | zorg ervoor dat |
| the system is designed to | het systeem is ontworpen om | het systeem stuurt … aan / het systeem is bedoeld om |
| will operate | zal werken | werkt / wordt aangestuurd |
| is high (probability) | is hoog | is groot |
| press and hold | druk en houd vast | houd … ingedrukt |
| if equipped | indien uitgerust | indien aanwezig |
| when the power switch is turned to ON | wanneer de contactschakelaar naar AAN wordt gedraaid | wanneer het contact wordt ingeschakeld |
| response center | responsecentrum | responscentrum |
| approximately 5 seconds | ongeveer 5 seconden (ok) — but never *circa 5 seconds* | ongeveer 5 seconden |

Also reject: English word order surviving into Dutch (verb-second and
verb-final violations), stacked prepositional strings where a compound is
idiomatic, and *deze* used where Dutch would repeat the noun.

**No *-functie* inside a bracketed qualifier.** English names a mode or
variant in brackets with *feature* or *function* (*Radar Cruise Control
(Map Integration Feature)*). In Dutch, *functie* after a technical term
and inside brackets reads heavy and clunky. Render the bracket with the
bare noun: *Cruisecontrol met radar (kaartintegratie)*, not *(kaartintegratiefunctie)*;
*kaartkoppeling* is equally acceptable. Apply the same form wherever the
feature name recurs in running text (*voorzorgsmaatregelen voor
kaartintegratie*). If a master-list entry itself contains *functie*
(*Functie voor vaart minderen in bochten*), the entry is binding: apply it
as it stands.

### Word Repetition Within a Segment

English tolerates repeating a content word inside one sentence; Dutch reads
it as clumsy, and it is corrected by hand on delivery. Remove it at source.

**Scope: within one segment only.** Repetition *across* segments is usually
correct and often mandatory — the same term must render identically
everywhere, which is what the Consistency Pass enforces. Never synonymise a
term to avoid repeating it in a neighbouring segment. Where the two pulls
conflict, consistency wins and the repetition stands.

Order of preference, strictest first:

1. **Keep one instance; eliminate the other.** Elimination beats
   synonymy every time. Try each of these against every repeated stem
   before concluding that the repetition has to stay — reaching for
   `DEDUP: retained` while an untried elimination exists is the common
   failure here:
   * gapping — of a verb (*ontgrendel eerst de portieren en daarna de
     aansluiting*), a preposition (*door een dealer, een reparateur of
     een hersteller*), or a head noun across coordinated modifiers
     (*een door SUBARU erkende of een andere betrouwbare reparateur*)
   * compounds — *laad- en ontlaadproces*, not *laadproces en
     ontlaadproces*
   * pronominal adverbs — *ervan*, *daarvan*, *daarmee*, *daarop*
   * relative subordination with *die/dat*, collapsing two clauses into one
   * zero anaphora where Dutch permits it and English does not
   * comparison anaphora — where a comparison repeats its head noun
     (*the charge shown may not match the display on the phone*, *differs
     from the value of the vehicle*), let a demonstrative stand in for the
     second instance: *De getoonde resterende batterijlading komt mogelijk
     niet overeen met die op de mobiele telefoon* (*die* = *de
     batterijlading*), *verschilt van dat van het voertuig*. Use *die* for
     de-words and plurals, *dat* for het-words; the anaphor conditions
     below apply. Prefer it to a paraphrase (*met wat de mobiele telefoon
     aangeeft*), which is wordier and gains nothing
2. **Synonymise only if elimination fails**, and only on non-terminological
   words. A word used consistently across the project is not thereby a
   bound term: if it appears in neither the master list nor
   the row's own Terminology column, it is ordinary vocabulary and may be
   varied. Watch for synonyms that carry a regional marker or collide
   with a false friend in a neighbouring language of the review chain.
3. **Restructure the sentence** if neither works. Fidelity is to meaning,
   never to the English sentence boundary.

**Where the repetition sits matters as much as how often it occurs.** Two
instances falling close together, and especially in the closing phrase of
a sentence, read as clumsy; the same two spread across separate clauses
usually do not. Judge by weight and position, not by a word count — and
prioritise the end of the sentence, where Dutch expects the weight to
settle.

**Terminology is untouchable by default.** A term may be replaced by an
anaphor (*deze*, *dit*, *ervan*) only when all three hold:

* the antecedent is the **nearest** preceding noun phrase;
* gender and number agree (*deze schakelaar*, *dit lampje*);
* **no competing noun phrase** stands between anaphor and antecedent.

If any one fails, leave the repetition. *Deze* reaching back past another
candidate noun is a defect, not a fix. Where the repetition survives
deliberately, say so in Notes — a `DEDUP: retained` line marks it as a
decision rather than an oversight, so it is not re-examined by hand.

**Approved exception: *auto* for the reader's own vehicle.** Apply the
binding term 'Vehicle' → *voertuig* strictly: the client has confirmed it
takes precedence over the house usage *auto* found in confirmed
neighbours, so that difference on its own is not raised as `HARMONISE:`.
The one sanctioned departure is for repetition. If applying the term would
put *voertuig* (or *voertuigen*) twice in one segment, and elimination
under step 1 fails or would lose the reference point, render the
occurrence that refers to the reader's own car as *auto* (*de auto*, *uw
auto*) and keep *voertuig* for the other vehicles. This does more than
avoid a repeat: *auto* marks the reader's car against the others, the same
split the confirmed text already makes.

* *Er zijn geen naderende voertuigen in de buurt van het voertuig* →
  *Er zijn geen naderende voertuigen in de buurt van de auto*
* *(uw voertuig kan de voorligger of het voertuig naast u volgen)* →
  *(uw auto kan de voorligger of het voertuig naast u volgen)*

If *voertuig* occurs only once in the segment, keep it; the exception
resolves a repetition and is not a route back to *auto* in general. If
every occurrence refers to another vehicle, the exception does not apply
and the ordinary rules above govern. Mark the row `DEDUP:` and say that
*auto* was used for the own vehicle as the approved synonym. TM units
stored before this rule may still repeat *voertuig*; apply the exception
anyway and mark the row `TM-ADAPTED:`.

Never let deduplication alter meaning, drop a qualifier, weaken a safety
instruction, or break a UI string that must match on-screen text. **When in
doubt, no change.**

### Settled Term Decisions

These were settled with the client's reviewer. Apply them without raising
`HARMONISE:` again.

**"Lane or course" (LDA, LTA, OAA).** The English *course* has three
senses in this manual, and each needs its own Dutch:

* **Road sense** — the car deviates from, or drives on, its *lane or
  course*. The course is the road itself, whose edge the manual's footnote
  defines (asphalt against grass or soil, a curb, a guardrail). Render
  *rijstrook of weg*, adding the article the sentence needs: *van de
  rijstrook of de weg afwijken*, *op een smalle rijstrook of weg*. This is
  the standing entry `lane or course,rijstrook of weg` in
  `reference/terminology.csv`. A footnote asterisk stays on the noun it
  follows in the source: `course*` → `weg*`.
* **Recognition sense** — the system recognises or detects a *lane or
  course*. What it sees are lines and edges, so render *rijstrookmarkering
  of wegrand*, and mark the displaced entry `TERM-CONTEXT:`.
* **Heading sense** — a vehicle *changes course*. Render *van koers
  veranderen*, which is correct and idiomatic. The standing entry is keyed
  on the whole phrase *lane or course* precisely so that it does not fire
  here; never add *course* alone to the terminology.

Rejected renderings, so they are not proposed again: *koers* for the road
sense (it means heading; older LDA units in the TM still carry it, so
override them and mark the row `FUZZY-REFINED:` or `TM-ADAPTED:`);
*rijbaan* (correct but stiff); *berm* (the verge beyond the edge, where the
car ends up rather than what it deviates from); and *wegrand* with
*afwijken van* (deviating from an edge means moving away from it — *wegrand*
works only with recognition or crossing verbs).

**"Object" (*object* or *voorwerp*).** The choice follows the sense, not
the chapter:

* ***object*** — anything the vehicle's sensors or systems detect, track or
  react to: the ADAS target, the parking-assist obstacle, the thing the
  sonar measures the distance to. *Wanneer het systeem vaststelt dat een
  gedetecteerd object zich van het voertuig heeft verwijderd*.
* ***voorwerp*** — a physical item that a person handles, places, hangs or
  inserts, or that gets in the way mechanically: things hung on the
  back-door handles, a pin in the power outlet, a bicycle carrier on the
  back door, something obstructing the seat. *Hang geen voorwerpen aan de
  handgrepen van de bagageklep*.

Two borderline cases are settled. Something touching or held near the
steering wheel is *voorwerp*: the system registers contact, not a detected
target (*Wanneer een ander voorwerp dan de hand van de bestuurder het stuur
raakt*). A small item under the rear bumper that falsely triggers the
hands-free back door is *voorwerp* too, since it is an accidental
obstruction, not a detection target (*Wanneer een klein dier of voorwerp
zoals een bal onder de achterbumper beweegt*).

The phrase-level forms are in the client's terminology list, so they reach
the workfile as binding `TERMS:` entries: *detectable object* →
*detecteerbaar object*, *detected object* → *gedetecteerd object*, *target
object* → *doelobject*, *moving object* → *bewegend object*. Bare *object*
deliberately has no entry, because a single binding rendering would be wrong
for one of the two senses; decide it by the rule above and do not mark it
`TERM-CONTEXT:`. *Static object* and *stationary object* are both
*stilstaand object* (plural *stilstaande objecten*), also in the
terminology list: it is by far the most frequent form across the manual,
and the few *statisch* renderings are a stray from earlier translators. TM
units that still carry *statisch* are overridden and marked `TM-ADAPTED:`;
*statisch* in a confirmed segment is drift for the Outside-the-batch
report.

A sensor-detected thing rendered as *voorwerp*, or a handled item rendered
as *object*, in a confirmed segment is house-term drift for the
Outside-the-batch report.

### Structural Patterns

* **Cross-reference**: *For details on X, refer to the [*]* → *Voor meer
  informatie over X raadpleegt u de [*]* (or *zie de [*]* per TM).
* **Warning/consequence**: state the instruction first, consequence second;
  *possibly leading to an accident* → *wat kan leiden tot een ongeval*.
* **Conditional safety line**: *If the system determines that…* → *Als het
  systeem detecteert dat…* — *detecteren/bepalen* per TM, never *beslist*.
* **Spec line**: nominal, no invented articles or verbs; unit and number
  formatting normalised to Dutch.
* **UI label**: short and nominal; no added articles, no sentence
  punctuation.
* **Comparison**: *X may not match the display/value on Y* → *X komt
  mogelijk niet overeen met die/dat op Y*, the demonstrative agreeing with
  X (see comparison anaphora under Word Repetition).

Workflow
--------

0. **Read the context file first**, if one is supplied. Locate every batch
   segment in it through `batch_map.csv`, and read the confirmed
   Dutch around each one before translating anything. Jot down anything
   that belongs in the Outside-the-batch report as you pass it, rather than
   re-reading the window for it later.
1. **Integrity check the whole file first.** Look for collapsed `""`
   escapes, unparseable `TERMS:` dicts, rows with the wrong field count, and
   truncated sources. Do not guess at mangled reference data — translate on
   the intact evidence and mark `INPUT-ERR:` with a one-line description.
   Note duplicate English sources now; they drive the Consistency Pass.
2. **Per row**: read columns 3–6 and the row's neighbourhood in the context
   file, establish what the string is, apply the Priority Hierarchy, write
   the finished Dutch into column 2.
3. **Note** every non-trivial decision using the taxonomy below. Routine
   exact-terminology application needs only `TERM-APPLIED`.
4. **Consistency Pass** over the whole file: group repeated and near-repeat
   English sources and verify identical Dutch renderings. `FRESH` rows lack
   anchors and are where drift appears. Mark any row changed
   `CONSISTENCY:`.
5. **Repetition Pass**, after the Consistency Pass so that terminology is
   already locked and visibly off-limits. Read each finished Dutch string on
   its own and flag any content word occurring twice. Function words and
   terminology are exempt from the flag. Apply the Word Repetition procedure
   above and mark the row `DEDUP:`, whether the repetition was removed or
   deliberately kept.
6. **Output**: write and verify the workfile as set out in Output Delivery
   Format below.
7. **Outside-the-batch fixes**: append untagged fixes to
   `context_fixes.csv`, and build the XML snippet (and
   `manual_fix_<fileid>_seg<n>.xml`) for each tagged one, as set out under
   Fixing reported defects.
8. **Report** in the reply, in the order and shape set out in Output
   Delivery Format.

Notes Taxonomy (coded prefixes)
-------------------------------

| Prefix | Meaning |
| --- | --- |
| `TERM-APPLIED` | Exact terminology from cols 3/4 used as-is |
| `TERM-CONTEXT:` | Terminology present but inflected or displaced for idiom; state how |
| `TM-ADAPTED` | TM pair used but re-cast (state why) |
| `FUZZY-REFINED` | `[FUZZY nn%]` pre-fill repaired; state what was wrong |
| `LOCALISED:` | Imperial measurement dropped or converted; state which |
| `FRESH` | No terminology or TM; translated under skill rules |
| `CONSISTENCY:` | Changed in the Consistency Pass to match a sibling row |
| `CONTEXT:` | Decided on evidence from the context file; give the segment numbers |
| `DEDUP:` | Within-segment word repetition removed, or deliberately retained; state which and how |
| `ACTIVE:` | Passive recast as active (or deliberately kept); state the agent used |
| `HARMONISE:` | Conflict or source-side issue needing a client decision |
| `INPUT-ERR:` | Malformed reference data in this row; describe briefly |
| `SPLIT:` | Row joins two Transit segments; say where to split on re-import |

`HARMONISE:` and `INPUT-ERR:` rows must also be summarised in a short list
after the CSV, so they can be raised with the client without re-scanning the
file. Where a context file was supplied, the Outside-the-batch report (see
The Context File) follows that summary.

Output Delivery Format
----------------------

This section fixes the shape of every delivery, so the user can import the
file and act on the reply without reformatting either. Treat it as a format
contract, not a judgment call.

### The workfile

* **Name and place.** Write the workfile back **in place**, under its
  input filename, in the user's working folder (normally
  `C:\Temp\core_dep\output.csv`); back it up first outside the folder.
  Where the folder is not reachable and the file was attached, deliver it
  under its input filename in `/mnt/user-data/outputs/` and send it to the
  user. It is the only batch file delivered; `terminology.csv` and
  `context_fixes.csv` are updated as set out elsewhere in this skill.
* **Byte shape.** Same encoding as the input (UTF-8; keep the BOM when the
  input has one, as `solterra.py` writes it), CRLF line endings, the same
  header row, the same row order, six columns in every row. Write it with Python's `csv` module and
  default minimal quoting, never by hand, so commas, quotes and curly
  quotes inside fields survive.
* **Columns 1, 3, 4, 5** are carried over unchanged, character for
  character.
* **Column 2** holds the final Dutch and nothing else: no `[FUZZY nn%]`
  tag, no alternatives, no brackets of your own, no comments.
* **Column 6** keeps any upstream text first. Append ` | ` and then the
  coded notes for the row, each coded item separated by ` | `, on one
  line. Every row gets at least one coded note. Name the evidence inside
  the note (term pair, segment numbers, what the pre-fill got wrong), so
  the note stands on its own in an audit.

### Verification in code, before delivery

Run a script that re-reads both files and checks:

* row count and column count unchanged; columns 1, 3, 4, 5 identical;
* column 2 non-empty in every data row, with no `[FUZZY` left;
* no imperial units, no *zal/zullen*, no *je*;
* no decimal point between digits, no straight double quote, no space
  before a colon;
* no row with *voertuig* twice;
* the number of double spaces in column 2 equals the number in column 1,
  in every row;
* the row count and column 1 still match `batch_map.csv`.

When `context_fixes.csv` was written, also check that every `current`
matches a context-file `Translation` byte for byte and contains no `<`.

Print only the verdict and any flagged rows. Then print a compact review
pass — each row's English, the Dutch, and the fuzzy source quoted in
column 6 where there is one — and read it before replying. The review
pass is for you; it does not go into the reply.

### The reply

Keep it to flagged items and the file tag. The user reads the file itself,
so do not recap rows, restate translations, or narrate the process. Use
this order and these headings, and omit any section that has no items
(never write "none"):

1. **Verdict line**: `Quality gate: **PASS**` (or `**FAIL**` with the rows
   and the check that failed). Add one clause only when something about
   the run matters to the user, such as all rows located with no splits,
   or the bundled copy of the terminology used because the GitHub fetch
   failed.
2. **`**Client decisions**`**: one bullet per issue, grouping rows that
   share an issue (`* **Rows 3, 20:** …`). Covers `HARMONISE:` items
   (including doubtful list entries), proposed standards for terms not in
   the master list, terms added to the list and GitHub, `INPUT-ERR:` rows,
   `SPLIT:` rows, and rows whose tags `import` cannot place (say where the
   tags go). Each bullet says what the problem is and what was applied.
3. **`**Outside the batch**`**: as set out under The Context File; one
   line per item, meaning errors first, with the correct Dutch and how it
   was handled. Then the XML inner-text snippets for tagged segments, each
   in its own `xml` code block.
4. **File tag**: the delivered filename(s) in backticks, as the last line
   (`output.csv`, plus `context_fixes.csv` and any
   `manual_fix_<fileid>_seg<n>.xml` written this turn).

### The Decision Log

Every item that goes under **Client decisions** or **Outside the batch**
is also logged, in the same turn, in the user's **Solterra Decision Log**
artifact (`https://claude.ai/artifact/LnRmUadW8ZkBjd9c7Dmvvm`). The log
replaces the user's own notes: it is where client queries are collected,
sent and answered. It is a database-backed page; write to it with the
`ArtifactData` tool (load it with ToolSearch first), never by
republishing the page.

* **Collection** `items`. One document per item, written in one `batch`
  per turn with `op: "set"` and new doc ids (`<fileprefix>-<seg>`, e.g.
  `ebt-7`; add `-2` when an id is taken). Before the first write of a
  conversation, `list` the collection once to learn the highest `order`.
* **Fields:** `order` (next integer), `date` (YYYY-MM-DD), `file` (Transit
  file ID from `current_file.txt`), `segs` (segment numbers, `;` between
  them, `-` for a range), `type`, `issue` (what the problem is, one line),
  `applied` (what the delivered Dutch does), `answer` (empty: the user
  fills it), `status` (`Open` or `Done`).
* **Type**, one of exactly these five:
  * `Client query` — needs the client's answer: a source typo or markup
    fault, a doubtful master-list entry, a TM unit that may be wrong, a
    label whose translation the client decides. `Open`.
  * `Internal (Frans)` — a choice that is the user's to make: a style
    split in the window (imperative against infinitive), a proposed
    standard or term not yet added, a `HARMONISE:` the user has not
    settled. `Open`.
  * `Decision` — settled in this batch on the skill's own rules and
    recorded for the audit trail: a list term overriding the TM, a fuzzy
    from an older revision, an outside-the-batch fix written to
    `context_fixes.csv`. `Done`.
  * `Term added` — a term appended to the master list and GitHub. `Done`.
  * `Manual Transit` — a tag `import` cannot place, a fix in a tagged
    segment that `context_fixes.csv` cannot apply, or a fix in a tagged
    legacy segment (delivered as an XML snippet). `Open`.
* **Skip** routine rows (plain term application, a fuzzy repaired without
  a decision, merged duplicates): log only what a reviewer or the client
  would want to see later.
* Never edit or delete existing items unless the user asks; when the
  user reports a client answer in chat, write it to `answer` and set
  `status` to `Done` (an `update` pinned with the version from a `get`).
* If the write fails, say so in one line of the reply and list the items
  there instead.

The reply stays as set out above; the log does not replace the
**Client decisions** bullets.

Follow-up deliverables in the same conversation use the
`"current","to_replace"` format (written to `context_fixes.csv` for
outside-the-batch items, a code block for a normalisation set), followed by
the short client-note list: a normalisation set as set out under The Master
Terminology List, and resolved Outside-the-batch items by the Resolution
Map under The Context File.

Bundled Reference Files
-----------------------

Read these when a row's own columns are thin, or when checking consistency
across a batch. Workfile columns always outrank them.

| File | Contents | When to read |
| --- | --- | --- |
| `reference/terminology.csv` | Fallback copy of the GitHub master list (about 2,200 EN→NL pairs, mandated and locally standardised; all binding). May be older than GitHub and the user's local copy | Only when neither GitHub nor the user's local `terminology.csv` can be read (see The Master Terminology List) |
| `reference/translation-memory.csv` | Approved full-segment pairs | Sentence-level near-matches |
| `reference/patterns.csv` | Recurring phrase-level renderings | Cross-references, safety phrasing, boilerplate |
| `reference/units.csv` | Client EN→NLD unit, number and punctuation table | **Any row containing a figure, unit, `No.`, or quotation mark** |

A supplied context file is not one of these. It outranks the TM, pattern
and unit files for house terms and register, being drawn from the live
project. For terminology the master list outranks it, because the window
can carry legacy renderings from earlier translators.

Quality Gate (final check before delivery)
------------------------------------------

* ☐ Every binding terminology match applied, inflected with `TERM-CONTEXT:`, or escalated with `HARMONISE:`
* ☐ Batch and window checked against the master list (live copy if the fetch succeeded)
* ☐ No `[FUZZY nn%]` tags left in column 2
* ☐ Every fuzzy row diffed against col 1: numbers, units, parentheses, and dropped clauses restored
* ☐ No imperial units anywhere in column 2 (mph, mile, lb., °F, in., ft., qt., gal., psi, cu.in., lbf)
* ☐ Metric alternates present where `units.csv` requires them (kp, kp·m, min-1)
* ☐ Volume as `l`, rotation as `rpm (min-1)`, pressure parenthesis using *of*
* ☐ Decimal commas throughout; grouping mirrors the source; `No.` → `Nr.`
* ☐ Curly quotes `“ ”` and apostrophe `’`; no space before a colon
* ☐ No future tense; imperative used for instructions; *u* not *je*
* ☐ No anglicisms or calques from the table above
* ☐ Every source hedge (*may*, *can*) kept; nothing hedged that the source states flatly
* ☐ *Object* for sensor-detected things, *voorwerp* for handled or obstructing items, per Settled Term Decisions
* ☐ *Lane or course* rendered per Settled Term Decisions: road sense *rijstrook of weg*, recognition sense *rijstrookmarkering of wegrand*, heading sense *koers*
* ☐ No content word repeated within a segment, unless retained with a `DEDUP: retained` note
* ☐ Every anaphor used to eliminate a repetition has the nearest antecedent, agreeing gender and number, and no competing noun in between
* ☐ No translationese: every string passes the native-author test
* ☐ Every passive checked; active used wherever a clear agent exists and it reads better, with hedges kept
* ☐ Compounds closed up; hyphens only after acronym, digit, brand, or vowel clash
* ☐ Brand, model, code, asterisk, and placeholder strings byte-identical to source
* ☐ Double spaces in column 2 match column 1 in number and order, each where its tag belongs; 100% TM rows restored
* ☐ Rows, row order and column 1 unchanged, so the workfile still matches `batch_map.csv`
* ☐ de/het correct throughout
* ☐ Repeated English sources → identical Dutch
* ☐ Where a context file was supplied: every batch row located in it through `batch_map.csv`, house terms taken from confirmed neighbours, register matched to the tags or `Struct`
* ☐ Workfile written in place and verified in code as set out in Output Delivery Format
* ☐ New terms appended to the local `terminology.csv` and pushed to GitHub, and named in the reply
* ☐ Every outside-the-batch defect in an untagged segment (legacy or not) written to `context_fixes.csv` in the same turn, without asking first
* ☐ Every outside-the-batch defect in a tagged segment given as an XML inner-text snippet in its own code block, with the whole `<Seg>` saved as UTF-16 and `Data` untouched
* ☐ Every Client-decisions and Outside-the-batch item logged in the Solterra Decision Log (`items`), with the right type and status
* ☐ Reply follows Output Delivery Format: verdict line, client decisions, outside-the-batch report with snippets, file tag; no recap
* ☐ Where the window showed meaning errors, term drift, on-sight defects or source-side faults in confirmed or edited segments (the user’s own *Edited, unconfirmed* segments included): Outside-the-batch report given, one line per item, severest first; context file untouched