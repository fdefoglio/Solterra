# -*- coding: utf-8 -*-
"""
transit_context.py - build a chronological context CSV from a Transit NXT
language pair (.ENU source + .NLD target).

Usage (Command Prompt):
    python transit_context.py A6790GEtoeuenvhch02.ENU A6790GEtoeuenvhch02.NLD
    python transit_context.py src.ENU tgt.NLD --out context_T1.csv
    python transit_context.py src.ENU tgt.NLD --batch output_T1.csv --window 15

Without --batch: every segment, document order.
With --batch:    only segments near a batch row (+/- --window), merged into
                 continuous runs, with a Batch column cross-referencing them.
"""
import argparse, csv, re, sys, xml.etree.ElementTree as ET

PUA = re.compile(r'([\ue000-\uf8ff])')
TAGNAME = re.compile(r'^<\s*/?\s*([A-Za-z_][\w.\-]*)')

# Status is a flag in the target file's Data attribute. Codes observed in the
# Solterra project; verify the labels against the colours in your own window.
STATUS = {
    ('\ue902', '\uee06'): 'Not translated',
    ('\ue902', '\uee0e'): 'Not translated',
    ('\ue90a', '\uee01'): 'Not for translation',   # markup/symbol copies
    ('\ue90a', '\uee05'): 'Translated',
    ('\ue908', '\uee05'): 'Translated (status 2)',
    ('\ue90a', '\uee0e'): 'Edited, unconfirmed',
    ('\ue90a', '\uee06'): 'Edited, unconfirmed',
}
S1 = ('\ue902', '\ue908', '\ue90a')
S2 = ('\uee01', '\uee05', '\uee06', '\uee0e')


def parse_data(data):
    """Split a Data attribute into (marker, payload) pairs."""
    parts = PUA.split(data or '')
    out, i = [], 1
    while i < len(parts):
        out.append((parts[i], parts[i + 1] if i + 1 < len(parts) else ''))
        i += 2
    return out


def read_pair(path):
    with open(path, encoding='utf-16') as f:
        return ET.fromstring(f.read())


def walk(root):
    """Yield (SegID, struct_path, text, Data) in document order."""
    body = root.find('Body')
    stack = []
    for el in body:
        if el.tag == 'Tag':
            t = el.text or ''
            m = TAGNAME.match(t)
            if not m:
                continue
            nm = m.group(1)
            if el.get('pos') == 'Begin' and not t.rstrip().endswith('/&gt;') \
                    and not t.rstrip().endswith('/>'):
                stack.append(nm)
            elif el.get('pos') == 'End' and nm in stack:
                while stack and stack.pop() != nm:
                    pass
        elif el.tag == 'Seg':
            yield (int(el.get('SegID')), '/'.join(stack[-3:]),
                   ''.join(el.itertext()), el.get('Data') or '')


def status_of(data):
    flags = {m for m, v in parse_data(data) if v == ''}
    a = next((c for c in S1 if c in flags), None)
    b = next((c for c in S2 if c in flags), None)
    label = STATUS.get((a, b), 'Unknown')
    code = '%s/%s' % (hex(ord(a)) if a else '-', hex(ord(b)) if b else '-')
    return label, code


def field(data, marker):
    for m, v in parse_data(data):
        if m == marker:
            return v
    return ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source'); ap.add_argument('target')
    ap.add_argument('--out', default='context.csv')
    ap.add_argument('--batch', help='workfile CSV; column 1 = English source')
    ap.add_argument('--window', type=int, default=15)
    a = ap.parse_args()

    src = {i: (p, t) for i, p, t, d in walk(read_pair(a.source))}
    tgt = {i: (p, t, d) for i, p, t, d in walk(read_pair(a.target))}

    missing = set(src) ^ set(tgt)
    if missing:
        print('WARNING: %d segment IDs are not in both files: %s'
              % (len(missing), sorted(missing)[:10]), file=sys.stderr)

    ids = sorted(set(src) & set(tgt))

    keep, batch_no = set(ids), {}
    if a.batch:
        with open(a.batch, encoding='utf-8-sig') as f:
            rows = list(csv.reader(f))[1:]
        wanted = {r[0].strip(): n for n, r in enumerate(rows, 1) if r and r[0].strip()}
        hits = [i for i in ids if src[i][1].strip() in wanted]
        for i in hits:
            batch_no[i] = wanted[src[i][1].strip()]
        keep = set()
        for i in hits:
            lo, hi = i - a.window, i + a.window
            keep |= {j for j in ids if lo <= j <= hi}
        print('batch rows: %d | matched segments: %d | context segments: %d'
              % (len(rows), len(hits), len(keep)))
        if len(hits) < len(rows):
            unmatched = set(wanted) - {src[i][1].strip() for i in hits}
            print('UNMATCHED batch sources (%d):' % len(unmatched), file=sys.stderr)
            for u in list(unmatched)[:10]:
                print('   ', u[:70], file=sys.stderr)

    with open(a.out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, lineterminator='\r\n')
        w.writerow(['Seg', 'Struct', 'Status', 'StatusCode',
                    'Author', 'EN', 'NL', 'Batch'])
        prev = None
        for i in ids:
            if i not in keep:
                continue
            if prev is not None and i != prev + 1:
                w.writerow(['...', '', '', '', '', '(gap: %d segments)'
                            % (i - prev - 1), '', ''])
            label, code = status_of(tgt[i][2])
            nl = tgt[i][1]
            if label == 'Not translated':
                nl = ''          # target is only an untranslated copy of EN
            w.writerow([i, tgt[i][0], label, code,
                        field(tgt[i][2], '\uef09'), src[i][1], nl,
                        batch_no.get(i, '')])
            prev = i
    print('wrote', a.out)


if __name__ == '__main__':
    main()
